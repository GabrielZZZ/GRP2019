# GRP-Project-WeChat-Mini-program

This is the GRP project front end code (WeChat Mini-program). 

It should run on **the WeChat developer toolkit** (download website: (https://developers.weixin.qq.com/miniprogram/en/dev/), introduction website: (https://developers.weixin.qq.com/miniprogram/en/dev/))
