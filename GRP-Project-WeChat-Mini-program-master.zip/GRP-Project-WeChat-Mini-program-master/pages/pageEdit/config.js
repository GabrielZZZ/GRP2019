/***************************************************************************************
*    Title: COS
*    Author: piscium2010
*    Date: 2019.3.5
*    Code version: 1.0
*    Availability: https://github.com/piscium2010/cos-wx-upload-file
*
***************************************************************************************/
var config = {
  Bucket: '',//replace with yours
  Region: '',//replace with yours
  SecretId: '',//replace with yours
  SecretKey: ''//replace with yours
}

module.exports = config
